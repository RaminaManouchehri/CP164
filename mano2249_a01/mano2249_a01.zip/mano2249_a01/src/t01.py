"""
-------------------------------------------------------
Assignment 1, Task 1
-------------------------------------------------------
Author:  Ramina Manouchehri
ID:      169042249
Email:   mano2249@mylaurier.ca
__updated__ = "2023-01-22"
-------------------------------------------------------
"""
# Imports
from functions import clean_list
# Constants

clean_list([1, 2, 0, 1, 4, 1, 1, 2, 2, 5, 4, 3, 1, 3, 3, 4, 2, 4, 3, 1, 3, 0, 3, 0, 0])