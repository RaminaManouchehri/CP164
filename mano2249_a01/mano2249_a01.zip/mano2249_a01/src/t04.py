"""
-------------------------------------------------------
Assignment 1, Task 4
-------------------------------------------------------
Author:  Ramina Manouchehri
ID:      169042249
Email:   mano2249@mylaurier.ca
__updated__ = "2023-01-23"
-------------------------------------------------------
"""
# Imports
from functions import is_leap_year
# Constants
year = 1600
leap_year = is_leap_year(year)
print(leap_year)