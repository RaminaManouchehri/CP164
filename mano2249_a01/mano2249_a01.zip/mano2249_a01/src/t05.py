"""
-------------------------------------------------------
Assignment 1, Task 5
-------------------------------------------------------
Author:  Ramina Manouchehri
ID:      169042249
Email:   mano2249@mylaurier.ca
__updated__ = "2023-01-23"
-------------------------------------------------------
"""
# Imports
from functions import is_valid
# Constants
name = "var"
valid = is_valid(name)
print(valid)