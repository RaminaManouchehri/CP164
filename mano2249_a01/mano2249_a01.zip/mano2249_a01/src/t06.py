"""
-------------------------------------------------------
Assignment 1, Task 6
-------------------------------------------------------
Author:  Ramina Manouchehri
ID:      169042249
Email:   mano2249@mylaurier.ca
__updated__ = "2023-01-23"
-------------------------------------------------------
"""
# Imports
from functions import matrix_transpose
# Constants
a = [[0, 1], [2, 3], [4, 5], [6, 7], [8, 9]]

b = matrix_transpose(a)
print(b)