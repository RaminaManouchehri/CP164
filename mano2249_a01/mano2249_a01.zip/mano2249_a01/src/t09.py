"""
-------------------------------------------------------
Assignment 1, Task 9
-------------------------------------------------------
Author:  Ramina Manouchehri
ID:      169042249
Email:   mano2249@mylaurier.ca
__updated__ = "2023-01-23"
-------------------------------------------------------
"""
# Imports
from functions import shift
# Constants
string = "David"
n = 1
estring = shift(string, n)
print(estring)